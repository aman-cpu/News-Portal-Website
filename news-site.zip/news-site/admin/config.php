<?php
$conn=mysqli_connect("localhost","root","","news-site")  or die('Connction Falied');
// echo 'hello';
?>